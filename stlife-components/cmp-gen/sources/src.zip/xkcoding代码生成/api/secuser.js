import request from '@/router/axios'

/**
 * 分页查询权限管理
 * @param query 分页查询条件
 */
export function fetchList(query) {
  return request({
    url: '/rbac/secuser',
    method: 'get',
    params: query
  })
}

/**
 * 新增权限管理
 * @param obj 权限管理
 */
export function addObj(obj) {
  return request({
    url: '/rbac/secuser',
    method: 'post',
    data: obj
  })
}

/**
 * 通过id查询权限管理
 * @param id 主键
 */
export function getObj(id) {
  return request({
    url: '/rbac/secuser/' + id,
    method: 'get'
  })
}

/**
 * 通过id删除权限管理
 * @param id 主键
 */
export function delObj(id) {
  return request({
    url: '/rbac/secuser/' + id,
    method: 'delete'
  })
}

/**
 * 修改权限管理
 * @param id 主键
 * @param obj 权限管理
 */
export function putObj(id, obj) {
  return request({
    url: '/rbac/secuser/' + id,
    method: 'put',
    data: obj
  })
}
