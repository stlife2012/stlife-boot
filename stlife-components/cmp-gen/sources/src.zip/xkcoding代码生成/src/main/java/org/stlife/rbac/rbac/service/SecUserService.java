package org.stlife.rbac.rbac.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.stlife.rbac.rbac.entity.SecUser;

/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package:  org.stlife.rbac.rbac.service
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
public interface SecUserService extends IService<SecUser> {

}
