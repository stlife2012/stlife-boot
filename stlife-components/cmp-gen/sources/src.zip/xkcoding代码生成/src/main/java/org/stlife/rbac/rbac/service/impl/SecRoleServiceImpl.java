package org.stlife.rbac.rbac.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.stlife.rbac.rbac.entity.SecRole;
import org.stlife.rbac.rbac.mapper.SecRoleMapper;
import org.stlife.rbac.rbac.service.SecRoleService;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package: org.stlife.rbac.rbac.service.impl
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
@Service
@Slf4j
public class SecRoleServiceImpl extends ServiceImpl<SecRoleMapper, SecRole> implements SecRoleService {

}
