package org.stlife.rbac.rbac.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package:  org.stlife.rbac.rbac.entity
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
@Data
@NoArgsConstructor
@TableName("sec_role")
@ApiModel(description = "权限管理")
@EqualsAndHashCode(callSuper = true)
public class SecRole extends Model<SecRole> {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId
    @ApiModelProperty(value = "主键")
    private Long id;
    /**
     * 角色名
     */
    @ApiModelProperty(value = "角色名")
    private String name;
    /**
     * 描述
     */
    @ApiModelProperty(value = "描述")
    private String description;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Long createTime;
    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Long updateTime;

}
