package org.stlife.rbac.rbac.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.stlife.rbac.rbac.common.R;
import org.stlife.rbac.rbac.entity.SecRole;
import org.stlife.rbac.rbac.service.SecRoleService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import lombok.extern.slf4j.Slf4j;
/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package:  org.stlife.rbac.rbac.controller
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
@Slf4j
@RestController
@RequestMapping("/secrole")
@Api(description = "SecRoleController", tags = {"权限管理"})
public class SecRoleController {
    @Autowired
    private  SecRoleService secRoleService;

    /**
     * 分页查询权限管理
     * @param page 分页对象
     * @param secRole 权限管理
     * @return R
     */
    @GetMapping("")
    @ApiOperation(value = "分页查询权限管理", notes = "分页查询权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "分页参数", required = true),
            @ApiImplicitParam(name = "secRole", value = "查询条件", required = true)
    })
    public R listSecRole(Page page, SecRole secRole) {
      return R.success(secRoleService.page(page,Wrappers.query(secRole)));
    }


    /**
     * 通过id查询权限管理
     * @param id id
     * @return R
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "通过id查询权限管理", notes = "通过id查询权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R getSecRole(@PathVariable("id") Long id){
      return R.success(secRoleService.getById(id));
    }

    /**
     * 新增权限管理
     * @param secRole 权限管理
     * @return R
     */
    @PostMapping
    @ApiOperation(value = "新增权限管理", notes = "新增权限管理")
    public R saveSecRole(@RequestBody SecRole secRole){
      return R.success(secRoleService.save(secRole));
    }

    /**
     * 修改权限管理
     * @param id id
     * @param secRole 权限管理
     * @return R
     */
    @PutMapping("/{id}")
    @ApiOperation(value = "修改权限管理", notes = "修改权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R updateSecRole(@PathVariable Long id, @RequestBody SecRole secRole){
      return R.success(secRoleService.updateById(secRole));
    }

    /**
     * 通过id删除权限管理
     * @param id id
     * @return R
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "删除权限管理", notes = "删除权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R deleteSecRole(@PathVariable Long id){
      return R.success(secRoleService.removeById(id));
    }

}
