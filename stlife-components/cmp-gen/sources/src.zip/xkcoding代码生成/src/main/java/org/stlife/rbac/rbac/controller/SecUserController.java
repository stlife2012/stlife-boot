package org.stlife.rbac.rbac.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.stlife.rbac.rbac.common.R;
import org.stlife.rbac.rbac.entity.SecUser;
import org.stlife.rbac.rbac.service.SecUserService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import lombok.extern.slf4j.Slf4j;
/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package:  org.stlife.rbac.rbac.controller
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
@Slf4j
@RestController
@RequestMapping("/secuser")
@Api(description = "SecUserController", tags = {"权限管理"})
public class SecUserController {
    @Autowired
    private  SecUserService secUserService;

    /**
     * 分页查询权限管理
     * @param page 分页对象
     * @param secUser 权限管理
     * @return R
     */
    @GetMapping("")
    @ApiOperation(value = "分页查询权限管理", notes = "分页查询权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "分页参数", required = true),
            @ApiImplicitParam(name = "secUser", value = "查询条件", required = true)
    })
    public R listSecUser(Page page, SecUser secUser) {
      return R.success(secUserService.page(page,Wrappers.query(secUser)));
    }


    /**
     * 通过id查询权限管理
     * @param id id
     * @return R
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "通过id查询权限管理", notes = "通过id查询权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R getSecUser(@PathVariable("id") Long id){
      return R.success(secUserService.getById(id));
    }

    /**
     * 新增权限管理
     * @param secUser 权限管理
     * @return R
     */
    @PostMapping
    @ApiOperation(value = "新增权限管理", notes = "新增权限管理")
    public R saveSecUser(@RequestBody SecUser secUser){
      return R.success(secUserService.save(secUser));
    }

    /**
     * 修改权限管理
     * @param id id
     * @param secUser 权限管理
     * @return R
     */
    @PutMapping("/{id}")
    @ApiOperation(value = "修改权限管理", notes = "修改权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R updateSecUser(@PathVariable Long id, @RequestBody SecUser secUser){
      return R.success(secUserService.updateById(secUser));
    }

    /**
     * 通过id删除权限管理
     * @param id id
     * @return R
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "删除权限管理", notes = "删除权限管理")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "主键id", required = true)
    })
    public R deleteSecUser(@PathVariable Long id){
      return R.success(secUserService.removeById(id));
    }

}
