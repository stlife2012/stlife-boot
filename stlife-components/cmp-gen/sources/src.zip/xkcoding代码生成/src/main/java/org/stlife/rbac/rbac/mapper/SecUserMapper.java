package org.stlife.rbac.rbac.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Component;
import org.stlife.rbac.rbac.entity.SecUser;

/**
 * <p>
 * 权限管理
 * </p>
 *
 * @package:  org.stlife.rbac.rbac.mapper
 * @description: 权限管理
 * @author: stlife
 * @date: Created in 2020-11-29 18:12:15
 * @copyright: Copyright (c) 2020
 * @version: V1.0
 * @modified: stlife
 */
@Component
public interface SecUserMapper extends BaseMapper<SecUser> {

}
